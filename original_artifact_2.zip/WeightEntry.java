package com.example.csweightracking;

public class WeightEntry {
    private int id;
    private String date;
    private float weight;
    private float height;
    private float bmi;

    public WeightEntry(int id, String date, float weight, float height, float bmi) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.height = height;
        this.bmi = bmi;
    }

    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public float getWeight() {
        return weight;
    }

    public float getHeight() {
        return height;
    }

    // Responsible for returning BMI value
    public float getBmi() {
        return bmi;
    }
}

