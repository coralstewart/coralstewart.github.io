package com.example.csweightracking;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private ArrayList<WeightEntry> entries; // Store WeightEntry objects
    private DatabaseHelper dbHelper; // Reference to DatabaseHelper for CRUD operations
    private OnItemClickListener onItemClickListener; // Listener for item clicks

    public DataAdapter(ArrayList<WeightEntry> entries, DatabaseHelper dbHelper, OnItemClickListener listener) {
        this.entries = entries;
        this.dbHelper = dbHelper; // Initialize DatabaseHelper
        this.onItemClickListener = listener; // Set the listener
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = entries.get(position);
        holder.dateTextView.setText(entry.getDate());
        holder.weightTextView.setText(String.valueOf(entry.getWeight()));
        holder.heightTextView.setText(String.valueOf(entry.getHeight()));
        holder.bmiTextView.setText(String.valueOf(entry.getBmi()));

        // Responsible for asking for user confirmation before deleting entry
        holder.deleteButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
            builder.setTitle("Delete Entry");
            builder.setMessage("You are about to delete an entry. Do you wish to continue?");

            // If user selects yes
            builder.setPositiveButton("Yes", (dialog, which) -> {
                dbHelper.deleteEntry(entry.getId());
                entries.remove(position);
                notifyItemRemoved(position);
            });

            // If user selects no
            builder.setNegativeButton("No", (dialog, which) -> {
            });

            builder.show();
        });

        // Set a click listener for the item view to enable editing
        holder.itemView.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(entry);
            }
        });
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView;
        TextView weightTextView;
        TextView heightTextView;
        TextView bmiTextView;
        Button deleteButton;

        ViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            heightTextView = itemView.findViewById(R.id.heightTextView);
            bmiTextView = itemView.findViewById(R.id.bmiTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(WeightEntry entry);
    }
}











