package com.example.csweightracking;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DataEntryActivity extends AppCompatActivity {

    private EditText weightInput, heightInput, dateInput;
    private Button addButton;
    private RecyclerView recyclerView;
    private DataAdapter dataAdapter;
    private DatabaseHelper dbHelper;
    private ArrayList<WeightEntry> entriesList;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_entry);

        // Stores userId at beginning of activity
        userId = getIntent().getIntExtra("USER_ID", -1);
        // Logout if userId did not pass
        if (userId == -1) {
            Toast.makeText(this, "User ID not found. Logging out now...", Toast.LENGTH_LONG).show();
            finish(); // Ends activity
            return;
        }

        dbHelper = new DatabaseHelper(this);
        weightInput = findViewById(R.id.weightInput);
        heightInput = findViewById(R.id.heightInput);
        dateInput = findViewById(R.id.dateInput);
        addButton = findViewById(R.id.addButton);
        recyclerView = findViewById(R.id.recyclerView);

        entriesList = new ArrayList<>();
        dataAdapter = new DataAdapter(entriesList, dbHelper, this::onItemClick); // Pass listener for clicks
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.setAdapter(dataAdapter);

        loadEntries(); // Load existing entries on startup

        addButton.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString();
            String heightStr = heightInput.getText().toString();
            String date = dateInput.getText().toString();

            if (!weightStr.isEmpty() && !heightStr.isEmpty() && !date.isEmpty()) {
                float weight = Float.parseFloat(weightStr);
                float height = Float.parseFloat(heightStr);

                // creates new entry and handles BMI calculation
                WeightEntry newEntry = new WeightEntry(-1, date, weight, height);

                dbHelper.insertWeightData(userId, weight, height, date, newEntry.getBmi()); // Insert data into database
                Toast.makeText(DataEntryActivity.this, "Weight entry added", Toast.LENGTH_SHORT).show();
                // Removed loadEntries(); from this line
                // because it was reloading the whole list, making it inefficient
                // instead, adds new entry manually (-1 is a temporary ID)


                // Adds entry to list and notifies adapter
                entriesList.add(newEntry);
                dataAdapter.notifyItemInserted(entriesList.size() - 1);

            } else {
                Toast.makeText(DataEntryActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadEntries() {
        entriesList.clear(); // Clear previous entries
        entriesList.addAll(dbHelper.getAllWeightEntries(userId)); // Fetch entries specific to a user

        // Now we call the new StatsHelper class to get BMI summary stats
        float avg = StatsHelper.getAverageBMI(entriesList);
        float max = StatsHelper.getMaxBMI(entriesList);
        float min = StatsHelper.getMinBMI(entriesList);

        // Show summary stats in a toast
        Toast.makeText(this,
                "Avg BMI: " + avg + " | Max: " + max + " | Min: " + min,
                Toast.LENGTH_LONG).show();

        dataAdapter.notifyDataSetChanged(); // Notify adapter of data changes
    }

    /*
     * sortByBMI method will sort BMI in ascending order
     * sortByDate method will sort entries by date
     * filterByBMIThreshold method will filter entries by a minimum BMI value
     */

    private void sortByBMI() {
        Collections.sort(entriesList, new Comparator<WeightEntry>() {
            @Override
            public int compare(WeightEntry e1, WeightEntry e2) {
                return Float.compare(e1.getBmi(), e2.getBmi());
            }
        });

        dataAdapter.notifyDataSetChanged(); // Refreshes the list
    }

    private void sortByDate() {
        Collections.sort(entriesList, new Comparator<WeightEntry>() {
            @Override
            public int compare(WeightEntry e1, WeightEntry e2) {
                return e1.getDate().compareTo(e2.getDate());
            }
        });

        dataAdapter.notifyDataSetChanged(); // Refreshes the list
    }

    private void filterByBMIThreshold(float threshold) {
        ArrayList<WeightEntry> filteredList = new ArrayList<>(); // Makes a temp list to hold matching entries

        for (WeightEntry entry : entriesList) {
            if (entry.getBmi() >= threshold) {
                filteredList.add(entry);
            }
        }
        // Adapter's list is replaced with a filtered list
        dataAdapter = new DataAdapter(filteredList, dbHelper, this::onItemClick);
        recyclerView.setAdapter(dataAdapter); // Updates the display
    }

    private void onItemClick(WeightEntry entry) {
        // Populate fields for editing
        weightInput.setText(String.valueOf(entry.getWeight()));
        heightInput.setText(String.valueOf(entry.getHeight()));
        dateInput.setText(entry.getDate());

        // Optionally, you can provide a mechanism to update the entry instead of adding a new one
        addButton.setText("Update Entry"); // Change button text for update

        addButton.setOnClickListener(v -> {
            // Logic for updating the entry
            String weightStr = weightInput.getText().toString();
            String heightStr = heightInput.getText().toString();
            String date = dateInput.getText().toString();

            // Ensures all fields are filled out
            if (!weightStr.isEmpty() && !heightStr.isEmpty() && !date.isEmpty()) {
                float weight = Float.parseFloat(weightStr);
                float height = Float.parseFloat(heightStr);
                float bmi = new WeightEntry(-1, date, weight, height).getBmi();


                // Use an update method (to be implemented in DatabaseHelper)
                dbHelper.updateWeightData(entry.getId(), userId, weight, height, date, bmi); // Update data
                Toast.makeText(DataEntryActivity.this, "Weight entry updated", Toast.LENGTH_SHORT).show();
                loadEntries(); // Reload entries after updating
                addButton.setText("Add Entry"); // Reset button text
            } else {
                Toast.makeText(DataEntryActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }
}







