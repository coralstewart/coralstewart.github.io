package com.example.csweightracking;
/*
 * This class contains the weight entry for the user's weight, height, and calculated BMI
 * The data structure here is used for storing these inputs
 */
public class WeightEntry {
    private int id;
    private String date;
    private float weight;
    private float height;
    private float bmi;
/*
 * This constructor takes weight and height and calculates BMI
 * @param id        id for weight entry
 * @param date      date of entry
 * @param weight    weight in lbs
 * @param height    height in inches
 */
    public WeightEntry(int id, String date, float weight, float height) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.height = height;
        this.bmi = calculateBMI(); // Will automatically calculate BMI
    }

    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public float getWeight() {
        return weight;
    }

    public float getHeight() {
        return height;
    }

    // Responsible for returning BMI value
    public float getBmi() {
        return bmi;
    }

    /*
     * Uses the formula BMI = weight (lb) / [height (m)]^2 to calculate BMI
     */
    private float calculateBMI() {
        // convert inches to meters
        float heightInMeters = height / 39.37f;
        // basic bmi formula
        return weight / (heightInMeters * heightInMeters);
    }
}


