package com.example.csweightracking;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.security.MessageDigest;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "csweightracking.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHT = "weight_entries";

    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    public static final String COLUMN_WEIGHT_ID = "weight_id";
    public static final String COLUMN_USER_ID_FK = "user_id";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_HEIGHT = "height";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_BMI = "bmi";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT NOT NULL,"
                + COLUMN_PASSWORD + " TEXT NOT NULL" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_WEIGHT_TABLE = "CREATE TABLE " + TABLE_WEIGHT + "("
                + COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_ID_FK + " INTEGER,"
                + COLUMN_WEIGHT + " REAL NOT NULL,"
                + COLUMN_HEIGHT + " REAL NOT NULL,"
                + COLUMN_DATE + " TEXT NOT NULL,"
                + COLUMN_BMI + " REAL NOT NULL,"
                + "FOREIGN KEY (" + COLUMN_USER_ID_FK + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(CREATE_WEIGHT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);

        // Hashes password prior to saving
        String hashedPassword = hashPassword(password);
        values.put(COLUMN_PASSWORD, hashedPassword);


        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        try {
            String hashedInput = hashPassword(password); // Checks database to see if user exists
            cursor = db.query(TABLE_USERS, null, // Checks database to see if user exists
                    COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                    new String[]{username, hashedInput}, null, null, null);


            if (cursor != null && cursor.moveToFirst()) {
                exists = true;
            }
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error checking user: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return exists;
    }

    /*
     * This method checks for a valid input before inserting it to database
     * It will return early if the input is invalid or data is missing
     *
     * @param userId  the user’s id (current temp is 1)
     * @param weight  user’s weight in lbs
     * @param height  user’s height in inches
     * @param date    date of the entry (mm/dd/yyyy format)
     */

    public void insertWeightData(int userId, float weight, float height, String date, float bmi) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Validates input to ensure no missing or negative values
        if (weight <= 0 || height <= 0 || date == null || date.trim().isEmpty()) {
            Log.e("DatabaseHelper", "Invalid input – entry not inserted.");
            db.close(); // Closes database even if input is rejected
            return;
        }

        // Prepares values for insertion
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID_FK, userId);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_HEIGHT, height);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_BMI, bmi);

        db.insert(TABLE_WEIGHT, null, values);
        db.close();
    }


    /*
     * Responsible for retrieving weight entries for specific user
     */

    public ArrayList<WeightEntry> getAllWeightEntries(int userId) {
        ArrayList<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            // Queries only the entries where the user_id foreign key matches the given user
            cursor = db.query(TABLE_WEIGHT, null,
                    COLUMN_USER_ID_FK + "=?",
                    new String[]{String.valueOf(userId)},
                    null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    // Pulls the data for each column in the current row
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT_ID));
                    float weight = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT));
                    float height = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_HEIGHT));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE));
                    float bmi = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_BMI));

                    // Creates a WeightEntry object and adds it to the result list
                    WeightEntry entry = new WeightEntry(id, date, weight, height);
                    entries.add(entry);
                } while (cursor.moveToNext()); // Continues until all user entries are fetched
            }
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error fetching entries: " + e.getMessage());
        } finally {
            // Closes cursor and database to avoid memory leaks
            if (cursor != null) cursor.close();
            db.close();
        }

        return entries; // Returns list of entries tied to that user
    }


    public void deleteEntry(int entryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHT, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(entryId)});
        db.close();
    }

    public void updateWeightData(int id, int userId, float weight, float height, String date, float bmi) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID_FK, userId);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_HEIGHT, height);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_BMI, bmi);

        db.update(TABLE_WEIGHT, values, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
        db.close();

    }

    /*
     * Method to hash passwords with SHA-256
     *
     * @param password the plaintext password
     * @return the hashed version in hex
     */
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes()); // Converts password to bytes
            StringBuilder hexString = new StringBuilder();

            // Turns each byte into a hex value
            for (byte b : hash) {
                hexString.append(Integer.toHexString(0xff & b));
            }
            return hexString.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /*
     * Gets user ID from the database using username.
     * This helps match the user with their weight entries
     */
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?", new String[]{username});

        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(0); // Gets ID from first column
            cursor.close(); // Closes cursor to prevent memory leaks
            db.close();     // Closes connection to database
            return userId;
        } else {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
            return -1; // Returns -1 if no user is found
        }
    }

}







