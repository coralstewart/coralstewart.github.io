package com.example.csweightracking;

import java.util.ArrayList;

/*
 * This is a helper class that calculates summary statistics
 * for minimum, maximum, and average BMI from a list
 */

public class StatsHelper {

    public static float getAverageBMI(ArrayList<WeightEntry> entries) {
        if (entries.isEmpty()) return 0;

        float total = 0;
        for (WeightEntry entry : entries) {
            total += entry.getBmi();
        }

        return total / entries.size(); // Formula for average
    }

    public static float getMaxBMI(ArrayList<WeightEntry> entries) {
        if (entries.isEmpty()) return 0;

        float max = entries.get(0).getBmi();
        for (WeightEntry entry : entries) {
            if (entry.getBmi() > max) {
                max = entry.getBmi();
            }
        }

        return max;
    }

    public static float getMinBMI(ArrayList<WeightEntry> entries) {
        if (entries.isEmpty()) return 0;

        float min = entries.get(0).getBmi();
        for (WeightEntry entry : entries) {
            if (entry.getBmi() < min) {
                min = entry.getBmi();
            }
        }

        return min;
    }
}