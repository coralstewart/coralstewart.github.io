package com.example.csweightracking;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataEntryActivity extends AppCompatActivity {

    private EditText weightInput, heightInput, dateInput;
    private Button addButton;
    private RecyclerView recyclerView;
    private DataAdapter dataAdapter;
    private DatabaseHelper dbHelper;
    private ArrayList<WeightEntry> entriesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_entry);

        dbHelper = new DatabaseHelper(this);
        weightInput = findViewById(R.id.weightInput);
        heightInput = findViewById(R.id.heightInput);
        dateInput = findViewById(R.id.dateInput);
        addButton = findViewById(R.id.addButton);
        recyclerView = findViewById(R.id.recyclerView);

        entriesList = new ArrayList<>();
        dataAdapter = new DataAdapter(entriesList, dbHelper, this::onItemClick); // Pass listener for clicks
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.setAdapter(dataAdapter);

        loadEntries(); // Load existing entries on startup

        addButton.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString();
            String heightStr = heightInput.getText().toString();
            String date = dateInput.getText().toString();

            if (!weightStr.isEmpty() && !heightStr.isEmpty() && !date.isEmpty()) {
                float weight = Float.parseFloat(weightStr);
                float height = Float.parseFloat(heightStr);
                float bmi = calculateBMI(weight, height); // Calculate BMI
                int userId = 1; // Replace with actual user ID logic

                dbHelper.insertWeightData(userId, weight, height, date, bmi); // Insert data
                Toast.makeText(DataEntryActivity.this, "Weight entry added", Toast.LENGTH_SHORT).show();
                loadEntries(); // Reload entries after adding
            } else {
                Toast.makeText(DataEntryActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadEntries() {
        entriesList.clear(); // Clear previous entries
        entriesList.addAll(dbHelper.getAllWeightEntries()); // Fetch new entries
        dataAdapter.notifyDataSetChanged(); // Notify adapter of data changes
    }

    private void onItemClick(WeightEntry entry) {
        // Populate fields for editing
        weightInput.setText(String.valueOf(entry.getWeight()));
        heightInput.setText(String.valueOf(entry.getHeight()));
        dateInput.setText(entry.getDate());

        // Optionally, you can provide a mechanism to update the entry instead of adding a new one.
        addButton.setText("Update Entry"); // Change button text for update

        addButton.setOnClickListener(v -> {
            // Logic for updating the entry
            String weightStr = weightInput.getText().toString();
            String heightStr = heightInput.getText().toString();
            String date = dateInput.getText().toString();

            if (!weightStr.isEmpty() && !heightStr.isEmpty() && !date.isEmpty()) {
                float weight = Float.parseFloat(weightStr);
                float height = Float.parseFloat(heightStr);
                float bmi = calculateBMI(weight, height);
                int userId = 1; // Replace with actual user ID logic

                // Use an update method (to be implemented in DatabaseHelper)
                dbHelper.updateWeightData(entry.getId(), userId, weight, height, date, bmi); // Update data
                Toast.makeText(DataEntryActivity.this, "Weight entry updated", Toast.LENGTH_SHORT).show();
                loadEntries(); // Reload entries after updating
                addButton.setText("Add Entry"); // Reset button text
            } else {
                Toast.makeText(DataEntryActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private float calculateBMI(float weight, float height) {
        return weight / ((height / 39.37f) * (height / 39.37f)); // Height in meters for BMI calculation
    }
}







